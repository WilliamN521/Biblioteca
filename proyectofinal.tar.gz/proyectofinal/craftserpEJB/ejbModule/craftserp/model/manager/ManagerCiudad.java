package craftserp.model.manager;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import craftserp.model.entities.SegCiudad;

/**
 * Session Bean implementation class ManagerCiudad
 */
@Stateless
@LocalBean
public class ManagerCiudad {

	@PersistenceContext
	private EntityManager em;
  
    public ManagerCiudad() {
        // TODO Auto-generated constructor stub
    }
// me sirve para consultar
	public List<SegCiudad> findAllCiudad() {
		String consulta = "SELECT s FROM SegCiudad s";
		Query q = em.createQuery(consulta, SegCiudad.class);
		return q.getResultList();
	}

	public SegCiudad findCiudadByNombre(String nombre) {
		return em.find(SegCiudad.class, nombre);
	}

	/*public void insertarCiudad(SegCiudad ciudad) throws Exception {
		if (findCiudadByNombre(ciudad.getNombre()) != null)
			throw new Exception("Ya existe la ciudad indicada");
		em.persist(ciudad.getNombre());
	}*/
	public void insertarCiudad(SegCiudad nuevaciudad) {
		SegCiudad c=new SegCiudad();
		c.setIdCiudad(nuevaciudad.getIdCiudad());
		c.setNombre(nuevaciudad.getNombre());
		em.persist(c);
	}


}
