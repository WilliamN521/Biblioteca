package craftserp.controller;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import craftserp.model.entities.SegCiudad;
import craftserp.model.manager.ManagerCiudad;

@Named
@SessionScoped
public class BeanCiudad implements Serializable{
	@EJB
	private ManagerCiudad managerCiudad;
	private List<SegCiudad> listaCiudad;
	private SegCiudad ciudad;
	private int idtipolibro;
	
	@PostConstruct
	public void inicializar() {
		listaCiudad=managerCiudad.findAllCiudad();
		ciudad = new SegCiudad();
	}

	/*public void actionListenerInsertarCiudad() {
		try {
			managerCiudad.insertarCiudad(ciudad);
			listaCiudad=managerCiudad.findAllCiudad();
			ciudad =new SegCiudad();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}*/
	public void actionListenerInsertarCiudad() {

		managerCiudad.insertarCiudad(ciudad);
		listaCiudad = managerCiudad.findAllCiudad();
		ciudad = new SegCiudad();
	}

	public List<SegCiudad> getListaCiudad() {
		return listaCiudad;
	}

	public void setListaCiudad(List<SegCiudad> listaCiudad) {
		this.listaCiudad = listaCiudad;
	}

	public SegCiudad getCiudad() {
		return ciudad;
	}

	public void setCiudad(SegCiudad ciudad) {
		this.ciudad = ciudad;
	}

	public int getIdtipolibro() {
		return idtipolibro;
	}

	public void setIdtipolibro(int idtipolibro) {
		this.idtipolibro = idtipolibro;
	}
	
	

}
